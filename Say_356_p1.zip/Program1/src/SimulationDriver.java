import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class SimulationDriver {
	public static void main(String[] args){
		int numberOfStudents = 50;
		Student[] students = generateListStudents(numberOfStudents);
		Question[] questions = {
				new question("a", Array.asList("A", "B","C", "D"), QuestionType.MultipleChoice);
				new Question("b", Array.asList("1. right", "2. wrong"), QuestionType.SingleChoice);
				new Question("c", Array.asList("A", "B", "C", "D",), QuestionType.MultipleChoice);
				new Question("d", Array.asList("1. right", "2. wrong"), QuestionType.SingleChoice);
		}
		for (Question question :  questions){
			iVoteService scanner in = new Scanner(System.in)
			for(int i = 0; i < students.length; i++){
				submitAnswer(Student[i], randomlySelectAnswer(question))
			}
			iVoteService.results();
		}
		
		private static Choice randomlySelectAnswer(Question question1){
			Choice choice;
			if(question1.getQuestionType().equals(QuestionType.SingleChoice)){
				choice = new SingleChoice(question1);
				
			} else{
				choice = new MultipleChoice(question1);
			}			
				return choice;
	}
}
