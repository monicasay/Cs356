import java.util.Objects;

public class Student {
	private String studentID;
	
	public Student(String student ID){
		this.studentID = studentID;
	}
	
	public int hasCode(){
		int hash = 5;
		hash = 97 * hash + Objects.hashCode(this.studentID);
		return hash;
	}
	public boolean equals(Object obj){
		return obj.toString().equals(studentID);
	}
	public String toString(){
		return studentID;
	}
}


public class SimulationDriver{
	public static void main(String[] args){
		
	}
}

