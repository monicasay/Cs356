
public interface iVoteService {
	public void submitAnswer(Student student, Choice answers);
	public void reuslts();

}
