import java.util.Arraylist;
import java.util.List;

public class Question {
		private String question;
		private List<Answer> answers;
		private QuestionType questionType;

		public Question(String question, List<String> answers, QuestionType questionType){
			this.question = question;
			this.answer = new ArrayList<>();
			for(String answer : answers){
				this.answers.add(new Answer(answers));
			}
			this.questionType = questionType;
		}
		
		public String getQuestion(){
			return question;
		}
		
		public void setQuestion(String question){
			this.question = question;
		}
		
		public QuestionType getQuestionType(){
			return questionType;
		}
		 public String toString(){
			 return question;
		 }
}
